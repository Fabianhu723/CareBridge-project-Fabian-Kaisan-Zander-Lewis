from flask import Flask, render_template, request
from datetime import datetime, date, timedelta

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/patient", methods=["GET", "POST"])
def patient():
    message = ""

    if request.method == "POST":
        name = request.form["name"]
        age = request.form["age"]
        patient_id = request.form["patient_id"]

        if name == "" or patient_id == "" or not age.isdigit() or int(age) <= 0:
            message = "Invalid patient details"
        else:
            message = "Patient added successfully"

    return render_template("patient.html", message=message)


@app.route("/booking", methods=["GET", "POST"])
def booking():
    message = ""

    if request.method == "POST":
        department = request.form["department"]
        appointment_date = request.form["date"]

        if department not in ["GP", "Specialist"] or appointment_date == "":
            message = "Error: Invalid department or date."

        else:
            try:
                appointment_date = datetime.strptime(
                    appointment_date, "%Y-%m-%d"
                ).date()

                today = date.today()
                maximum_date = today + timedelta(days=7)

                if appointment_date <= today or appointment_date > maximum_date:
                    message = "Error: Appointment date must be within the next 7 days."

                else:
                    message = (
                        "Booking confirmed for "
                        + department
                        + " on "
                        + appointment_date.strftime("%d/%m/%Y")
                        + "."
                    )

            except ValueError:
                message = "Error: Date is not correctly entered."

    return render_template("booking.html", message=message)


@app.route("/billing", methods=["GET", "POST"])
def billing():
    result = ""

    if request.method == "POST":
        patient_type = request.form["patient_type"]
        lab_tests = request.form["lab_tests"]

        if lab_tests.isdigit():
            BASE_FEE = 100
            LAB_TEST_RATE = 10

            subtotal = BASE_FEE + (int(lab_tests) * LAB_TEST_RATE)

            if patient_type == "Subsidised":
                total = subtotal * 0.70
            else:
                total = subtotal

            result = "Total amount to pay: $" + format(total, ".2f")

        else:
            result = "Invalid number of lab tests"

    return render_template("billing.html", result=result)


@app.route("/triage", methods=["GET", "POST"])
def triage():
    result = ""

    if request.method == "POST":
        severity = request.form["severity"]

        if severity.isdigit():
            severity = int(severity)

            if 1 <= severity <= 4:
                result = "Waiting Room"

            elif 5 <= severity <= 7:
                result = "Room 1"

            elif 8 <= severity <= 10:
                result = "Room 2"

            else:
                result = "Invalid severity level"

        else:
            result = "Invalid severity level"

    return render_template("triage.html", result=result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)